﻿using System;

namespace SingleMessage.Internal.Commands.Sales
{
    public class SendOrder
    {
    }
}
