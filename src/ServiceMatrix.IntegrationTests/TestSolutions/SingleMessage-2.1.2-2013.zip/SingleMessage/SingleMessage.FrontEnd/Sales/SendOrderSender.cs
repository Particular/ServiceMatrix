﻿using System;
using NServiceBus;
using SingleMessage.Internal.Commands.Sales;


namespace SingleMessage.Sales
{
    public partial class SendOrderSender
    {
		
    }
}
