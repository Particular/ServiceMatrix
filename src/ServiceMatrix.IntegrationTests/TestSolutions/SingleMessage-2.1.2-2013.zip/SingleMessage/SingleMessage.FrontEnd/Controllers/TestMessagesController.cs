﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace SingleMessage.FrontEnd.Controllers
{
    public partial class TestMessagesController
    {
        // TODO: SingleMessage.FrontEnd: Configure sent/published messages' properties implementing the partial Configure[MessageName] method.");
    }
}

