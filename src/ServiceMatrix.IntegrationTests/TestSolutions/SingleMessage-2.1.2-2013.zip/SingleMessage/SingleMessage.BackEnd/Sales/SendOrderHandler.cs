﻿using System;
using NServiceBus;
using SingleMessage.Internal.Commands.Sales;


namespace SingleMessage.Sales
{
    public partial class SendOrderHandler
    {
		
        partial void HandleImplementation(SendOrder message)
        {
            // TODO: SendOrderHandler: Add code to handle the SendOrder message.
            Console.WriteLine("Sales received " + message.GetType().Name);
        }

    }
}
