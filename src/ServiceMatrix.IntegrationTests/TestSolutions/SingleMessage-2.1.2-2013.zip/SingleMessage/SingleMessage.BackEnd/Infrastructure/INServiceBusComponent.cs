﻿namespace ServiceMatrix.Shared
{
    public interface INServiceBusComponent
    {
    }
}