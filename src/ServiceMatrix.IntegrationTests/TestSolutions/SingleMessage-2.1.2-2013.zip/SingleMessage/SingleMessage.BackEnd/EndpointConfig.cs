﻿using System;
using NServiceBus;
 
namespace SingleMessage.BackEnd
{
  public partial class EndpointConfig    
  {
      
  }
}
